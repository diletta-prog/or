#!/usr/bin/python3
# -*- coding: utf-8 -*-
import json
import logging
from simulator import instance
from solver.gurobisol import Gurobisol
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
from simulator.instance import Instance
from gurobipy import *
from scipy import sparse
import itertools 
from heuristic.shortestpath import Shortestpath
from etc.matrice import Matrice 
import math
np.random.seed(0)
import sys
 
path = './results/otput.txt'
sys.stdout = open(path, 'w')
if __name__ == '__main__':
    log_name = "./logs/main.log"
    logging.basicConfig(
        filename=log_name,
        format='%(asctime)s %(levelname)s: %(message)s',
        level=logging.INFO, datefmt="%H:%M:%S",
        filemode='w'
    )

models=['model S Sedan Long Range','model X SUV Long Range Plus', 'model 3 Sedan Longe Range', 'model Y Long Range'] 
print("The following models are available :")
print(models)
print("please choose a model: ")
  
for j in range(1,21):
    print("\n") 
    print("SIMULATION NUMBER "+ str(j))
    mygraph,n=Instance(j).create_graph(models)
    print(Shortestpath.dijkstra(mygraph,130,0,n-1,j))
    M,td,qd=Matrice.matrix()
    fixed_velocity= 130
    print("\n") 
    Gurobisol.solve(mygraph,fixed_velocity,td,qd,M)
    
