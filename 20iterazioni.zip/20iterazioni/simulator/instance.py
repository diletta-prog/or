
import logging
import numpy as np
import random
import networkx as nx
import itertools as it
import matplotlib.pyplot as plt

MIN_LAYERS = 4
MAX_LAYERS = 6

MIN_NODES_LAYER = 1
MAX_NODES_LAYER = 3

INTER_PROBA = 1
INTRA_PROBA = .2
SKIP_PROBA = .1

l=0.9
h=1.1


class Instance:

    def __init__(self, seed):
        self.seed = seed

    def create_graph(self,models):
        logging.info("starting simulation...")
        np.random.seed(self.seed)
        car=np.random.choice(models)
        print("you have chosen : ", car)

        if car=="model S Sedan Long Range":
                capacity= 100
                alpha_base= 2.21 * 10**(-3)
        if car=="model X SUV Long Range Plus":
                capacity=100
                alpha_base= 2.33 * 10**(-3)
        if car== "model 3 Sedan Longe Range":
                capacity=78
                alpha_base= 1.5 * 10**(-3)
        if car=="model Y Long Range":
                capacity= 75
                alpha_base= 2.09 * 10**(-3)

        n_interlayers = np.random.randint(MIN_LAYERS, MAX_LAYERS + 1)
        #print('ok',n_interlayers)
        # set number of nodes per layer
        layers_nodes = {0:1}
        layers_nodes.update(
            {
                k:v for k, v in zip(
                range(1, n_interlayers+1),
                np.random.randint(MIN_NODES_LAYER, MAX_NODES_LAYER, (n_interlayers,))
            )
            }
        )
        layers_nodes[n_interlayers + 1] = 1

        # set nodes identifiers
        nodes = {}
        total_nodes = 0
        for layer, n_nodes in layers_nodes.items():
            nodes[layer] = list(np.arange(n_nodes)+total_nodes)
            total_nodes += n_nodes
        print(total_nodes ,'total number of nodes')
        # create graph
        G = nx.DiGraph()
        G.add_nodes_from(range(total_nodes))


        # add inter-layer links
        for layer in range(n_interlayers+1):
            for i in nodes[layer]:
                for j in nodes[layer+1]:
                    if np.random.random() < INTER_PROBA:
                        G.add_edge(i, j, km=np.random.randint(100,200),alpha=alpha_base*((h-l)*np.random.random()+l),cost=0, costplot=0) # ADD ATTRIBUTES

        # add intra-layer links
        for layer in range(n_interlayers):
            for i, j in it.product(nodes[layer], nodes[layer]):
                if i == j: continue # avoid link to self
                if np.random.random() < INTRA_PROBA:
                    G.add_edge(i, j, km=np.random.randint(50,100),alpha=alpha_base*((h-l)*np.random.random()+l),cost=0, costplot=0) # ADD ATTRIBUTES

        # add skip-layer links
        for layer1 in range(n_interlayers):
            for layer2 in range(layer1+2, n_interlayers+2):
                for i, j in it.product(nodes[layer1], nodes[layer2]):
                    if np.random.random() < SKIP_PROBA:
                        G.add_edge(i, j,km=np.random.randint(200,300),alpha=alpha_base*((h-l)*np.random.random()+l),cost=0, costplot=0)  # ADD ATTRIBUTES

        #nx.draw_kamada_kawai(G, arrows=True)
        # nx.draw_circular(G, arrows=True)
        
        if G.has_edge(0,total_nodes-1):
           G.remove_edge(0,total_nodes-1)
        return G,total_nodes

        