# -*- coding: utf-8 -*-
import time
import logging
from typing import Any
import gurobipy as gp
from queue import PriorityQueue
from math import inf
from heuristic.splitwisefunction import Splitwisefunction
import networkx as nx
import numpy as np
from heuristic.plot import Plot
from gurobipy import GRB



class Shortestpath :
    def __init__(self):
        pass

   
    def dijkstra(graph,velocity,start, end,j) :
        
        n=graph.number_of_nodes()
        M= np.zeros((n,n))
        M[0,0]=100
        
       
        def backtrace(prev, start, end):
         node = end
         path = []
         while node != start:
            path.append(node)
            node = prev[node]
         path.append(node) 
         path.reverse()
         return path

        #   """get the cost of edges from node -> node
        def cost(u, v, prec):
            
            distance=graph.get_edge_data(u,v).get('km') 
            alpha=graph.get_edge_data(u,v).get('alpha') 
            
            q_left=M[prec,int(u)]
            q_left,t_recharge= Splitwisefunction.ComputeTimeRecharge(velocity,alpha,distance,q_left)
            #print(u,v,distance,alpha,t_recharge)
            M[int(u),int(v)]=q_left
            #(t_recharge)
            graph[u][v]['cost']=t_recharge+distance/velocity*60
            graph[u][v]['costplot']=round(t_recharge+distance/velocity*60,2)
            return distance/velocity *60 + t_recharge
         

     # predecessor of current node on shortest path 
        prev = {} 
      # initialize distances from start -> given node i.e. dist[node] = dist(start, node)
        dist = {v: inf for v in list(nx.nodes(graph))} 
       # nodes we've visited
        visited = set() 
       # prioritize nodes from start -> node with the shortest distance!
       ## elements stored as tuples (distance, node) 
        pq = PriorityQueue()  
    
        dist[start] = 0  # dist from start -> start is zero
        pq.put((dist[start], start))
    
        while 0 != pq.qsize():
          
          curr_cost, curr = pq.get()
          visited.add(curr)
          #print(f'visiting {curr}')
          
         
          
          # look at curr's adjacent nodes
          for neighbor in dict(graph.adjacency()).get(curr):
            
            # if we found a shorter path 
            if not prev :
                  prec = int(0)
                  
            else:
               if curr in prev:
                 prec=int(prev[curr])
                 
               else:
                   prec=int(0)
                   
            path = dist[curr] + cost(curr, neighbor, prec)
            if path < dist[neighbor]:
                
                # update the distance, we found a shorter one!
                dist[neighbor] = path
                # update the previous node to be prev on new shortest path
                prev[neighbor] = curr
                # if we haven't visited the neighbor
                if neighbor not in visited:
                    # insert into priority queue and mark as visited
                    visited.add(neighbor)
                    pq.put((dist[neighbor],neighbor))
               
        print("\n")
        print("=== Dijkstra's Algo Output ===")
        print("Distances")
        print(dist)
        print("Visited")
        print(visited)
        print("Previous")
        print(prev)
        km_totali=0
        print("\n")
        for i in range(len(backtrace(prev, start, end))-1):
          distance=graph.get_edge_data(backtrace(prev, start, end)[i],backtrace(prev, start, end)[i+1]).get('km') 
          km_totali=km_totali+distance
          time_rechage=graph.get_edge_data(backtrace(prev, start, end)[i],backtrace(prev, start, end)[i+1]).get('cost')- distance/velocity *60
          print(" at  node "+ str(i) +" the car charges for " +str(time_rechage))
        print("total km : "+ str(km_totali))
       # we are done after every possible path has been checked 
        Plot.plotpath(backtrace(prev, start, end),graph,j)
        #print(M)
        print(" final solution : ")
        return backtrace(prev, start, end), dist[end]

  


    
