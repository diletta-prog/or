#!/usr/bin/python3
# -*- coding: utf-8 -*-
import json
import logging
from simulator import instance
from solver.gurobisol import Gurobisol
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
from simulator.instance import Instance
from simulator.tester import Tester
from gurobipy import *
from scipy import sparse
import itertools 
from heuristic.shortestpath import Shortestpath
from utility.plot_results import plot_comparison_hist
from etc.matrice import Matrice 
import math
np.random.seed(0)

if __name__ == '__main__':
    log_name = "./logs/main.log"
    logging.basicConfig(
        filename=log_name,
        format='%(asctime)s %(levelname)s: %(message)s',
        level=logging.INFO, datefmt="%H:%M:%S",
        filemode='w'
    )

    
for j in range(1,4):
    print(j)
    mygraph,n=Instance(j).create_graph()
    print(Shortestpath.dijkstra(mygraph,130,0,n-1))
    M,td,qd=Matrice.matrix()
    fixed_velocity= 130
    Gurobisol.solve(mygraph,fixed_velocity,td,qd,M)
