class Splitwisefunction():
    def __init__(self):
        pass

    def ComputeTimeRecharge( velocity, alpha, distance, q_left) :
     
         s1 = 50.0;    #soglie curva di ricarica
         s2 = 75.0;
         s3 = 90.0;
         s4 = 100.0;
         m1 = 5/2;   #coefficenti angolari rette
         m2 = 5/6;
         m3 = 1/2;
         m4 = 1/3;
         t1=0
         t2=0
         t3=0
         t4=0
         Q_low=10

         c=alpha*velocity*distance

         Q=float (q_left)
         

         if (Q >= c) :
             return (Q-c, 0)
         
         else :
            if (Q < s1) :
               
               
                if (c > s1) :
                    
                    t1 = (s1-Q)/m1;
                    Q = s1;
                    
                else :
                    
                    t1 = (c-Q)/m1;
                    Q = 0.0;
                    
                
            if (Q < s2 and Q != 0.0) :
                
                if (c > s2) :
                    
                    t2 = (s2-Q)/m2;
                    Q = s2;
                    
                else :
                    
                    t2 = (c-Q)/m2;
                    Q = 0.0;
                    
            
            if (Q < s3 and Q != 0.0) :
                if (c > s3) :
                    
                    t3 = (s3-Q)/m3;
                    Q = s3;
                    
                else :
                   
                    t3 = (c-Q)/m3;
                    Q = 0.0;
                    
            
            if (Q < s4 and Q != 0.0) :
                    
                    t4 = (c-Q)/m4;
                    Q = 0.0;
                
            

            return(Q,t1+t2+t3+t4)
            #for i in range(n):
  #  for t in range(110):
  #      try:
   #         print(q_o[i], type(q_o[i]), int(q_o[i]))
   #     except KeyError:
   #         print(f"q_o KeyError {i}")
   #     try:
    #        print(q_i[i], type(q_i[i]), int(q_o[i]))
   #     except KeyError:
   #         print(f"q_i KeyError {i}")
   #     try:
   #         print(y[i][t][q_i[i]], type(y[i][t][q_i[i]]), int(y[i][t][q_i[i]]))
   #     except KeyError:
   #         print(f"y KeyError {t} {i} {q_i[i]}")
   #     try:
   #         print(M[t][q_i[i]], type(M[t][q_i[i]]), int(M[t][q_i[i]]))
   #     except KeyError:
   #         print(f"M KeyError {t} {i} {q_i[i]}")
            
