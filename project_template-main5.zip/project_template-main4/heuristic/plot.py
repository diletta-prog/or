import logging
import matplotlib.pyplot as plt
import networkx as nx
from networkx.generators import directed



class Plot():
    def __init__(self):
        pass
    def plotpath(path, graph):
        
        red_edges=[(path[int(i)],path[i+1]) for i in range(0,len(path)-1) ]
        edge_colours = ['black' if not edge in red_edges else 'red' for edge in graph.edges()]
        black_edges = [edge for edge in graph.edges() if edge not in red_edges]
        edge_labels=dict([((u,v,),d['cost'])
                 for u,v,d in graph.edges(data=True)])
        pos = nx.spring_layout(graph)
        nx.draw_networkx_nodes(graph, pos, cmap=plt.get_cmap('jet'), node_size = 500)
        nx.draw_networkx_edge_labels(graph,pos,edge_labels=edge_labels)
        nx.draw_networkx_labels(graph, pos)
        nx.draw_networkx_edges(graph, pos, edgelist=red_edges, edge_color='r', arrows=True)
        nx.draw_networkx_edges(graph, pos, edgelist=black_edges, arrows=True)
        plt.show()
        return

