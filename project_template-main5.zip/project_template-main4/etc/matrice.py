#!/usr/bin/python3
# -*- coding: utf-8 -*-

import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import sys
from gurobipy import *
from scipy import sparse
import itertools 



import numpy as np
import math

class Matrice :
    def __init__(self):
        pass

    def matrix():
      td = 111 # tempo per ricaricare batteria da 0 a 100%
      qd = 101  # livello massimo batteria
   
      # soglie temporali
      st1 = 20
      st2 = 50
      st3 = 80
      st4 = 110

      # soglie batteria
      sb1 = 50
      sb2 = 75
      sb3 = 90
      sb4 = 100

      M = np.zeros((td, qd))

      for i in range(0, td, 1):
          for j in range(0, qd, 1):
             if j <= sb1:
                 tempo = (2 / 5) * j
             elif j <= sb2:
                 tempo = (6 / 5) * j- 40
             elif j <= sb3:
                 tempo = 2 * j - 100
             else:
                 tempo = 3 * j - 190

             if (i + tempo) <= st1:
                 percentuale = (5 / 2) * (i + tempo)
             elif (i + tempo) <= st2:
                 percentuale = (5 / 6) * (i + tempo) + 100 / 3
             elif (i + tempo) <= st3:
                 percentuale = (1 / 2) * (i + tempo) + 50
             elif (i + tempo) <= st4:
                 percentuale = (1 / 3) * (i + tempo) + 190 / 3
             else:
                 percentuale = qd-1

             M[i][j] = math.trunc(percentuale)-j
          
      return(M,td,qd)
