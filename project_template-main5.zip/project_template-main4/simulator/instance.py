
import logging
import numpy as np
import random
import networkx as nx
import itertools as it
import matplotlib.pyplot as plt

MIN_LAYERS = 2
MAX_LAYERS = 5

MIN_NODES_LAYER = 2
MAX_NODES_LAYER = 5

INTER_PROBA = 1
INTRA_PROBA = .2
SKIP_PROBA = .1

l1=0.002
h1=0.00250
h2=0.0066153
l2=0.003
h3=0.001923
l3=0.001538

class Instance:

    def __init__(self, seed):
        self.seed = seed

    def create_graph(self):
        logging.info("starting simulation...")
        np.random.seed(self.seed)

        n_interlayers = np.random.randint(MIN_LAYERS, MAX_LAYERS + 1)
        print('ok',n_interlayers)
        # set number of nodes per layer
        layers_nodes = {0:1}
        layers_nodes.update(
            {
                k:v for k, v in zip(
                range(1, n_interlayers+1),
                np.random.randint(MIN_NODES_LAYER, MAX_NODES_LAYER, (n_interlayers,))
            )
            }
        )
        layers_nodes[n_interlayers + 1] = 1

        # set nodes identifiers
        nodes = {}
        total_nodes = 0
        for layer, n_nodes in layers_nodes.items():
            nodes[layer] = list(np.arange(n_nodes)+total_nodes)
            total_nodes += n_nodes
        print(total_nodes ,'nodi totali')
        # create graph
        G = nx.DiGraph()
        G.add_nodes_from(range(total_nodes))


        # add inter-layer links
        for layer in range(n_interlayers+1):
            for i in nodes[layer]:
                for j in nodes[layer+1]:
                    if np.random.random() < INTER_PROBA:
                        G.add_edge(i, j, km=np.random.randint(100,300),alpha=(h1-l1)*np.random.random()+l1,cost=0) # ADD ATTRIBUTES

        # add intra-layer links
        for layer in range(n_interlayers):
            for i, j in it.product(nodes[layer], nodes[layer]):
                if i == j: continue # avoid link to self
                if np.random.random() < INTRA_PROBA:
                    G.add_edge(i, j, km=np.random.randint(50,100),alpha=(h2-l2)*np.random.random()+l2,cost=0) # ADD ATTRIBUTES

        # add skip-layer links
        for layer1 in range(n_interlayers):
            for layer2 in range(layer1+2, n_interlayers+2):
                for i, j in it.product(nodes[layer1], nodes[layer2]):
                    if np.random.random() < SKIP_PROBA:
                        G.add_edge(i, j,km=np.random.randint(300,400),alpha=(h3-l3)*np.random.random()+l3,cost=0)  # ADD ATTRIBUTES

        #nx.draw_kamada_kawai(G, arrows=True)
        # nx.draw_circular(G, arrows=True)
        
        if G.has_edge(0,total_nodes-1):
           G.remove_edge(0,total_nodes-1)
        return G,total_nodes

#Instance(1234).create_graph()
        