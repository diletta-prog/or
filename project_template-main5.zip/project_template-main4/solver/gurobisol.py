#!/usr/bin/python3
# -*- coding: utf-8 -*-
import json
import logging
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
from gurobipy import *

from scipy import sparse
import itertools 
from utility.plot_results import plot_comparison_hist
import math

class Gurobisol :
    def __init__(self):
        pass

    def solve(mygraph,fixed_velocity,td,qd,M) :
        m=Model('SP')
        n=mygraph.number_of_nodes()
        x=m.addMVar((n,n), vtype=GRB.BINARY, name='x') #matrice delle x decision variables
        c=1000*np.ones((n,n)) #matrice dei costi c inizializzata a valori altissimi
        for link in mygraph.edges() :   #inserisco valori in c
           a=int(link[0])
           b=int(link[1])
           km=int((mygraph[link[0]][link[1]]['km']))
           c[a][b]=km/fixed_velocity*60
        print(c)  #matrice Q dei consumi necessari per ogni link inizializzata al massimo
        Q=100*np.ones((n,n))   #matrice Q dei consumi necessari per ogni link inizializzata al massimo
        for link in mygraph.edges() :  #inserisco i valori in Q
           a=int(link[0]) 
           b=int(link[1])
           km=float((mygraph[link[0]][link[1]]['km']))
           alpha=float((mygraph[link[0]][link[1]]['alpha']))
           Q[a][b]=math.ceil(km*alpha*fixed_velocity)
        f=n-1
        print (Q)
        y = m.addMVar((f,td,qd),vtype=GRB.BINARY, name='y')
        z = m.addMVar((f,td,qd),vtype=GRB.BINARY,name='z')
        a=m.addMVar((n,n), vtype=GRB.INTEGER, name='a')
        N=1000
        q_o=m.addMVar(shape=f, vtype=GRB.INTEGER,name='qout')  #carica out (array di lunghezza n)
        q_i=m.addMVar(shape=f, vtype=GRB.INTEGER,name='qin')  #carica in  (array di lunghezza n)
        m.addConstrs(a[i][j] <= x[i][j]*N for i,j in itertools.product(range(n),range(1,n)))
        m.addConstrs(a[i][j]>= 0 for i,j in itertools.product(range(n),range(1,n)) )
        m.addConstrs(a[i][j] >= q_o[i]-Q[i][j]-(1-x[i][j])*N*100000 +(a[i][j]-q_o[i]+Q[i][j])*N for i,j in itertools.product(range(f),range(1,n)))
        m.addConstrs(q_i[j] == sum(a[i][j] for i in range(n)) for j in range(1,f))
        m.addConstr(q_i[0]==100)  #carica iniziale massima()
        m.addConstr(q_o[0]==100)
        m.addConstrs(y[0][t][q]==0 for t in range(td) for q in range(qd))
        m.addConstrs(a[j][0]==0 for j in range(n))
        u=m.addMVar((f,qd), vtype=GRB.BINARY,name='u')
        m.addConstrs(z[i][t][q] <= y[i][t][q] for i in range(f) for t in range(td) for q in range(qd))
        m.addConstrs(z[i][t][q] <= u[i][q] for t in range(td) for q in range(qd) for i in range(f) )
        m.addConstrs(z[i][t][q]>= y[i][t][q] +u[i][q] -1  for t in range(td) for q in range(qd) for i in range(f))
        m.addConstrs(q_o[i] >= sum(Q[i][j]*x[i][j] for j in range(n))for i in range(1,f))
        m.addConstrs(sum(q*u[i][q] for q in range(qd))== q_i[i] for i in range(f))
        m.addConstrs(sum(u[i][q] for q in range(qd))==1 for i in range(f) )
        m.addConstrs(x[i][0]==0 for i in range(1,n))
        m.addConstrs(x[f][i]==0 for i in range(f))
        m.addConstrs(x[i][i]==0 for i in range(n))
        m.addConstr(sum(x[0][i] for i in range(n))==1)
        m.addConstr(sum(x[i][f] for i in range(n))==1)
        m.addConstrs(sum(x[i][j] for i in range(n))==sum(x[j][i] for i in range(n)) for j in range(1,f))
        m.addConstrs(q_o[i]==q_i[i] + sum( z[i][t][q]*M[t][q] for t,q in itertools.product(range(td),range(qd))) for i in range(f))
        m.setObjective(sum(x[i][j]*c[i][j] for i,j in itertools.product(range(n),range(n)))+sum(y[i][t][q]*t for i in range(f) for t in range(td) for q in range(qd)),GRB.MINIMIZE)

        m.optimize()
        m.printAttr('x')
